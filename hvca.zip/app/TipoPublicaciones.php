<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TipoPublicaciones extends Model
{
     protected $table = 'tipos_publicaciones';
}
