<?php

use Illuminate\Database\Seeder;

class seeder_tabla_pais extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {



$var[1]='Colombia';
$var[2]='Albania';
$var[3]='Alemania';
$var[4]='Andorra';
$var[5]='Angola';
$var[6]='Antigua y Barbuda';
$var[7]='Arabia Saudita';
$var[8]='Argelia';
$var[9]='Argentina';
$var[10]='Armenia';
$var[11]='Australia';
$var[12]='Austria';
$var[13]='Azerbaiyán';
$var[14]='Bahamas';
$var[15]='Bahrein';
$var[16]='Bangladesh';
$var[17]='Barbados';
$var[18]='Bélgica';
$var[19]='Bélice';
$var[20]='Benin';
$var[21]='Bielorrusia';
$var[22]='Bolivia';
$var[23]='Bosnia y Herzegovina';
$var[24]='Botsuana';
$var[25]='Brasil';
$var[26]='Brunei';
$var[27]='Bulgaria';
$var[28]='Burkina Faso';
$var[29]='Burundi';
$var[30]='Bután';
$var[31]='Cabo Verde';
$var[32]='Camboya';
$var[33]='Camerún';
$var[34]='Canadá';
$var[35]='Chad';
$var[36]='Chile';
$var[37]='China';
$var[38]='Chipre';
$var[39]='Colombia';
$var[40]='Comoras';
$var[41]='Corea del Norte';
$var[42]='Corea del Sur';
$var[43]='Costa de Marfil';
$var[44]='Costa Rica';
$var[45]='Croacia';
$var[46]='Cuba';
$var[47]='Dinamarca';
$var[48]='Dominica';
$var[49]='Ecuador';
$var[50]='Egipto';
$var[51]='El Salvador';
$var[52]='Emiratos Arabes Unidos';
$var[53]='Eritrea';
$var[54]='Eslovaquia';
$var[55]='Eslovenia';
$var[56]='España';
$var[57]='Estados Unidos';
$var[58]='Estonia';
$var[59]='Etiopía';
$var[60]='Filipinas';
$var[61]='Finlandia';
$var[62]='Fiyi';
$var[63]='Francia';
$var[64]='Gab�n';
$var[65]='Gambia';
$var[66]='Georgia';
$var[67]='Ghana';
$var[68]='Granada';
$var[69]='Grecia';
$var[70]='Guatemala';
$var[71]='Guinea';
$var[72]='Guinea Ecuatorial';
$var[73]='Guinea Francesa';
$var[74]='Guinea-Bissau';
$var[75]='Guyana';
$var[76]='Haití';
$var[77]='Honduras';
$var[78]='Hungría';
$var[79]='India';
$var[80]='Indonesia';
$var[81]='Irán';
$var[82]='Iraq';
$var[83]='Irlanda';
$var[84]='Islandia';
$var[85]='Islas Georgias del Sur y Sandwich del Sur';
$var[86]='Islas Malvinas';
$var[87]='Islas Marshall';
$var[88]='Islas Salom�n';
$var[89]='Israel';
$var[90]='Italia';
$var[91]='Jamaica';
$var[92]='Jap�n';
$var[93]='Jordania';
$var[94]='Kazajistán';
$var[95]='Kenia';
$var[96]='Kirguistán';
$var[97]='Kiribati';
$var[98]='Kuwait';
$var[99]='Laos';
$var[100]='Leshoto';
$var[101]='Letonia';
$var[102]='Líbano';
$var[103]='Libia';
$var[104]='Liechtenstein';
$var[105]='Lituania';
$var[106]='Luxemburgo';
$var[107]='Madagascar';
$var[108]='Malasia';
$var[109]='Malaui';
$var[110]='Maldivas';
$var[111]='Mali';
$var[112]='Malta';
$var[113]='Marruecos';
$var[114]='Mauricio';
$var[115]='Mauritania';
$var[116]='México';
$var[117]='Micronesia';
$var[118]='Moldavia';
$var[119]='M�naco';
$var[120]='Mongolia';
$var[121]='Montenegro';
$var[122]='Mozambique';
$var[123]='Myanmar (birmania)';
$var[124]='Namibia';
$var[125]='Nauru';
$var[126]='Nepal';
$var[127]='Nicaragua';
$var[128]='Níger';
$var[129]='Nigeria';
$var[130]='Noruega';
$var[131]='Nueva Zelanda';
$var[132]='Omán';
$var[133]='Países Bajos';
$var[134]='Pakistán';
$var[135]='Palaos';
$var[136]='Panamá';
$var[137]='Papúa Nueva Guinea';
$var[138]='Paraguay';
$var[139]='Perú';
$var[140]='Polonia';
$var[141]='Portugal';
$var[142]='Puerto Rico';
$var[143]='Qatar';
$var[144]='Reino Unido';
$var[145]='República Centroafricana';
$var[146]='República Checa';
$var[147]='República de Macedonia';
$var[148]='República del Congo';
$var[149]='República DemocrAtica del Congo';
$var[150]='República Dominicana';
$var[151]='república saharaui';
$var[152]='Ruanda';
$var[153]='Rumania';
$var[154]='Rusia';
$var[155]='Samoa';
$var[156]='San Crist�bal y Nevis';
$var[157]='San Marino';
$var[158]='San Vicente y las Granadinas';
$var[159]='Santa Lucía';
$var[160]='Santo Tomé y Príncipe';
$var[161]='Senegal';
$var[162]='Serbia';
$var[163]='Seychelles';
$var[164]='Sierra Leona';
$var[165]='Singapur';
$var[166]='Siria';
$var[167]='Somalia';
$var[168]='Sri Lanka';
$var[169]='Suazilandia';
$var[170]='SudAfrica';
$var[171]='SudAn del norte';
$var[172]='Sudan del sur';
$var[173]='Suecia';
$var[174]='Suiza';
$var[175]='Surinam';
$var[176]='Tailandia';
$var[177]='Tanzania';
$var[178]='Tayikistán';
$var[179]='Timor Oriental';
$var[180]='Togo';
$var[181]='Tonga';
$var[182]='Trinidad y Tobago';
$var[183]='Túnez';
$var[184]='Turkmenistán';
$var[185]='Turquía';
$var[186]='Tuvalu';
$var[187]='Ucrania';
$var[188]='uganda';
$var[189]='Uruguay';
$var[190]='Uzbekistán';
$var[191]='Vanuatu';
$var[192]='Vaticano';
$var[193]='Venezuela';
$var[194]='Vietnam';
$var[195]='Yemen';
$var[196]='Yibuti';
$var[197]='Zambia';
$var[198]='Zimbabue';
$var[199]='Antiguo';


       for ($i=1;$i<=199; $i++){
           DB::table('pais')->insert([
            'id' => $i,
            'nombre' => $var[$i], 
          ]);

        }


    }

    //composer dump-autoload
    //luego php artisan db:seed --class:seeder_tabla_pais



}
